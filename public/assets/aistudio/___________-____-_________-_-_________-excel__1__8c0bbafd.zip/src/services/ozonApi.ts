/**
 * Ozon Marketplace API & Live Tariffs Service
 * Интеграция с официальным Ozon Seller API с поддержкой ключа "Администратор (только чтение)"
 * Полная выгрузка всей информации:
 * - Каталог товаров: артикулы (offer_id, product_id, sku), названия, штрихкоды, категории
 * - Физические габариты упаковки (длина, ширина, высота, вес) и расчет точного объема в литрах
 * - Все изменяемые параметры: предельная розничная цена, цена для налога, себестоимость/закупка, реклама
 * - Официальные сборы Ozon: комиссии FBO/FBS, логистические тарифы по литражу, последняя миля, эквайринг, кросс-док
 * - Склад отгрузки: FBO кластеры (Тула/Москва, СПб, Казань) и активные FBS склады продавца
 */

import { ProductUnitData, ProductDimensions } from '../types/unitEconomics';
import { getLogisticsTariff, DEFAULT_WAREHOUSE_NAME } from '../utils/calculator';

export interface OzonCredentials {
  clientId: string;
  apiKey: string;
  lastSync?: string;
  sellerName?: string;
  keyType?: 'admin_read_only' | 'admin' | 'products' | 'custom';
  totalProducts?: number;
  warehousesCount?: number;
}

export interface OzonWarehouse {
  warehouse_id: number;
  name: string;
  is_rf?: boolean;
  status?: string;
  can_print_act_in_advance?: boolean;
}

export interface OzonCategoryTariff {
  id: string;
  name: string;
  commissionUnder300: number; // %
  commissionOver300: number; // %
  lastMilePercent: number; // % (стандарт 4.9% - 5.5%)
  acquiringPercent: number; // % (1.5%)
  crossDockFixed: number; // ₽
  fulfillmentFixed: number; // ₽
  notes: string;
}

// Актуальные официальные тарифы Ozon (2024–2025) по категориям
export const OZON_OFFICIAL_CATEGORY_TARIFFS: OzonCategoryTariff[] = [
  {
    id: 'beauty_special',
    name: 'Красота и косметика (Спец. тариф магазина: 23% / 52%)',
    commissionUnder300: 23,
    commissionOver300: 52,
    lastMilePercent: 4.9,
    acquiringPercent: 1.5,
    crossDockFixed: 1.63,
    fulfillmentFixed: 10,
    notes: 'Фактическая сетка из вашей таблицы Excel (лист Тарифы)',
  },
  {
    id: 'beauty_standard',
    name: 'Косметика, парфюмерия и гигиена (Общий FBO Ozon)',
    commissionUnder300: 21,
    commissionOver300: 24,
    lastMilePercent: 5.5,
    acquiringPercent: 1.5,
    crossDockFixed: 2.0,
    fulfillmentFixed: 12,
    notes: 'Стандартный регламент Ozon FBO для категории Уход и Красота',
  },
  {
    id: 'apparel',
    name: 'Одежда, обувь и аксессуары',
    commissionUnder300: 23,
    commissionOver300: 26,
    lastMilePercent: 5.5,
    acquiringPercent: 1.5,
    crossDockFixed: 2.5,
    fulfillmentFixed: 15,
    notes: 'FBO регламент Ozon: примерка, возвраты, базовая логистика',
  },
  {
    id: 'home_goods',
    name: 'Товары для дома, кухни и интерьера',
    commissionUnder300: 20,
    commissionOver300: 23,
    lastMilePercent: 5.5,
    acquiringPercent: 1.5,
    crossDockFixed: 2.0,
    fulfillmentFixed: 10,
    notes: 'FBO регламент Ozon для товаров повседневного спроса',
  },
  {
    id: 'electronics',
    name: 'Электроника, гаджеты и аксессуары',
    commissionUnder300: 14,
    commissionOver300: 17,
    lastMilePercent: 5.5,
    acquiringPercent: 1.5,
    crossDockFixed: 2.0,
    fulfillmentFixed: 10,
    notes: 'Сниженная ставка комиссии Ozon для электроники',
  },
  {
    id: 'auto',
    name: 'Автотовары и автохимия',
    commissionUnder300: 19,
    commissionOver300: 22,
    lastMilePercent: 5.5,
    acquiringPercent: 1.5,
    crossDockFixed: 2.5,
    fulfillmentFixed: 12,
    notes: 'FBO регламент для автотоваров',
  },
  {
    id: 'fbs_standard',
    name: 'Ozon FBS (Продажи со своего склада продавца)',
    commissionUnder300: 21,
    commissionOver300: 24,
    lastMilePercent: 5.5,
    acquiringPercent: 1.5,
    crossDockFixed: 0,
    fulfillmentFixed: 30, // Обработка отправления на СЦ Ozon
    notes: 'Логистика по тарифам FBS Ozon (приемка в СЦ / ПВЗ + магистраль)',
  },
];

const OZON_STORAGE_KEY = 'ozon_seller_api_config_v3';

/**
 * Очистка и санитизация введенных ключей (удаляет пробелы, кавычки, префиксы Client-Id / Api-Key)
 */
export function sanitizeCredential(raw: string): string {
  if (!raw) return '';
  return raw
    .trim()
    .replace(/^Client-Id:\s*/i, '')
    .replace(/^Api-Key:\s*/i, '')
    .replace(/^["'`]|["'`]$/g, '')
    .trim();
}

/**
 * Получить сохраненные ключи Ozon API
 */
export function getSavedOzonCredentials(): OzonCredentials | null {
  try {
    const raw =
      localStorage.getItem(OZON_STORAGE_KEY) ||
      localStorage.getItem('ozon_seller_api_config_v2') ||
      localStorage.getItem('ozon_seller_api_config');
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/**
 * Сохранить ключи Ozon API
 */
export function saveOzonCredentials(creds: OzonCredentials): void {
  const sanitized: OzonCredentials = {
    ...creds,
    clientId: sanitizeCredential(creds.clientId),
    apiKey: sanitizeCredential(creds.apiKey),
    keyType: creds.keyType || 'admin_read_only',
  };
  localStorage.setItem(OZON_STORAGE_KEY, JSON.stringify(sanitized));
}

/**
 * Очистить ключи Ozon API
 */
export function clearOzonCredentials(): void {
  localStorage.removeItem(OZON_STORAGE_KEY);
  localStorage.removeItem('ozon_seller_api_config_v2');
  localStorage.removeItem('ozon_seller_api_config');
}

/**
 * Вызов метода Ozon Seller API через прокси
 * Всегда использует только безопасные READ-ONLY эндпоинты, совместимые с ключом
 * «Администратор (только чтение)» (Admin Read-Only).
 */
export async function callOzonApi<T>(
  endpoint: string,
  body: Record<string, unknown>,
  credentials: OzonCredentials
): Promise<{ success: boolean; data?: T; status?: number; error?: string }> {
  const cId = sanitizeCredential(credentials.clientId);
  const aKey = sanitizeCredential(credentials.apiKey);

  if (!cId || !aKey) {
    return { success: false, error: 'Не указан Client-Id или Api-Key' };
  }

  const url = endpoint.startsWith('/') ? `/api/ozon${endpoint}` : `/api/ozon/${endpoint}`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Id': cId,
        'Api-Key': aKey,
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      let errDetail = `HTTP ${response.status}: ${response.statusText}`;
      try {
        const errorJson = await response.json();
        if (errorJson.message) {
          errDetail = errorJson.message;
        } else if (errorJson.error?.message) {
          errDetail = errorJson.error.message;
        } else if (errorJson.details?.[0]?.message) {
          errDetail = errorJson.details[0].message;
        }
      } catch {
        // fallback
      }

      if (response.status === 401) {
        errDetail = `Ошибка авторизации (401). Неверный Client-Id (${cId}) или Api-Key. Проверьте правильность копирования из Ozon Seller.`;
      } else if (response.status === 403) {
        errDetail = `Ошибка доступа (403 Forbidden). Убедитесь, что ключ создан с ролью «Администратор (только чтение)» (Admin read-only) или «Товары» и активирован в личном кабинете.`;
      }

      return { success: false, status: response.status, error: errDetail };
    }

    const json = await response.json();
    return { success: true, status: response.status, data: json as T };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Сетевая ошибка при запросе к Ozon API';
    return { success: false, error: message };
  }
}

/**
 * Получить список реальных складов продавца из Ozon (/v1/warehouse/list)
 */
export async function fetchOzonWarehouses(credentials: OzonCredentials): Promise<{
  success: boolean;
  warehouses: OzonWarehouse[];
  error?: string;
}> {
  const cId = sanitizeCredential(credentials.clientId);
  const aKey = sanitizeCredential(credentials.apiKey);

  if (!cId || !aKey) {
    return { success: false, warehouses: [], error: 'Не указаны ключи доступа' };
  }

  const res = await callOzonApi<{ result?: OzonWarehouse[] }>(
    '/v1/warehouse/list',
    {},
    { clientId: cId, apiKey: aKey }
  );

  if (res.success && Array.isArray(res.data?.result)) {
    return {
      success: true,
      warehouses: res.data.result,
    };
  }

  return {
    success: false,
    warehouses: [],
    error: res.error || 'Не удалось получить список складов',
  };
}

/**
 * Проверка подключения к Ozon Seller API с ключом типа "Admin Read Only"
 */
export async function testOzonConnection(credentials: OzonCredentials): Promise<{
  success: boolean;
  message: string;
  sellerName?: string;
  totalProducts?: number;
  warehousesCount?: number;
  warehouses?: OzonWarehouse[];
}> {
  const cId = sanitizeCredential(credentials.clientId);
  const aKey = sanitizeCredential(credentials.apiKey);

  if (!cId || !aKey) {
    return {
      success: false,
      message: 'Укажите Client-Id и Api-Key из личного кабинета Ozon Seller (раздел Настройки -> API ключи)',
    };
  }

  // 1. Проверяем каталог товаров
  let totalProducts = 0;
  let productsSuccess = false;
  let lastError = '';

  const v3Res = await callOzonApi<{
    result?: {
      items?: unknown[];
      total?: number;
      last_id?: string;
    };
  }>(
    '/v3/product/list',
    {
      filter: { visibility: 'ALL' },
      last_id: '',
      limit: 1,
    },
    { clientId: cId, apiKey: aKey }
  );

  if (v3Res.success && v3Res.data?.result) {
    productsSuccess = true;
    totalProducts = v3Res.data.result.total ?? 0;
  } else {
    lastError = v3Res.error || '';
    const v2Res = await callOzonApi<{
      result?: {
        items?: unknown[];
        total?: number;
      };
    }>(
      '/v2/product/list',
      {
        filter: { visibility: 'ALL' },
        limit: 1,
      },
      { clientId: cId, apiKey: aKey }
    );

    if (v2Res.success && v2Res.data?.result) {
      productsSuccess = true;
      totalProducts = v2Res.data.result.total ?? 0;
    } else if (v2Res.error) {
      lastError = v2Res.error;
    }
  }

  if (!productsSuccess) {
    return {
      success: false,
      message: lastError || 'Не удалось связаться с Ozon API. Проверьте правильность Client-Id и Api-Key.',
    };
  }

  // 2. Проверяем склады
  const whRes = await fetchOzonWarehouses({ clientId: cId, apiKey: aKey });
  const warehouses = whRes.warehouses || [];

  return {
    success: true,
    message: `Подключение успешно установлено! Ключ «Администратор (только чтение)» подтвержден. В каталоге Ozon товаров: ${totalProducts}, активных складов селлера: ${warehouses.length}.`,
    sellerName: `Магазин Ozon (Client-Id: ${cId})`,
    totalProducts,
    warehousesCount: warehouses.length,
    warehouses,
  };
}

/**
 * Прогресс выполнения синхронизации
 */
export type SyncProgressCallback = (statusText: string, progressPercent: number) => void;

/**
 * Опции синхронизации Ozon
 */
export interface FetchOzonOptions {
  selectedWarehouse?: string;
  selectedWarehouseType?: 'FBO' | 'FBS';
  selectedWarehouseId?: string | number;
  defaultCogsPercent?: number; // % себестоимости для новых позиций (по умолч. 25)
  defaultTaxPriceRatio?: number; // Коэффициент цены для налога (по умолч. 1.0 или 0.9)
  defaultAdSpendPercent?: number; // ДРР % по умолч. (16)
}

/**
 * Структура детальной информации о товаре из Ozon
 */
interface RawOzonProductAttribute {
  id: number;
  offer_id: string;
  name: string;
  barcode?: string;
  barcodes?: string[];
  category_id?: number;
  depth?: number;
  width?: number;
  height?: number;
  dimension_unit?: string;
  weight?: number;
  weight_unit?: string;
  price?: string | number;
  old_price?: string | number;
  marketing_price?: string | number;
  min_price?: string | number;
  volume_weight?: number;
}

interface RawOzonProductPrice {
  product_id: number;
  offer_id: string;
  price: {
    price: string | number;
    old_price: string | number;
    min_price?: string | number;
    marketing_price?: string | number;
    marketing_seller_price?: string | number;
    retail_price?: string | number;
  };
  commissions?: {
    sales_percent?: number;
    sales_percent_fbo?: number;
    sales_percent_fbs?: number;
    fbo_deliv_to_customer_amount?: number;
    acquiring?: number;
  };
  volume_weight?: number;
}

/**
 * Получить ВСЮ информацию по товарам из Ozon с ключом Admin Read Only:
 * - Все товары каталога продавца
 * - Точные физические габариты упаковки (длина, ширина, высота, вес) и расчет объема в литрах
 * - Актуальные цены реализации (price) и старые цены
 * - Официальные комиссии Ozon FBO/FBS
 * - Бережное сохранение всех введенных ранее параметров (закупка/cogs, цена для налога, реклама)
 * - Назначение склада отгрузки
 */
export async function fetchLiveOzonProducts(
  credentials: OzonCredentials,
  existingProducts: ProductUnitData[] = [],
  options?: FetchOzonOptions,
  onProgress?: SyncProgressCallback
): Promise<{
  success: boolean;
  products?: ProductUnitData[];
  message: string;
  totalSynced?: number;
  warehouses?: OzonWarehouse[];
  stats?: {
    pricesUpdated: number;
    dimensionsUpdated: number;
    commissionsUpdated: number;
  };
}> {
  const cId = sanitizeCredential(credentials.clientId);
  const aKey = sanitizeCredential(credentials.apiKey);

  if (!cId || !aKey) {
    return {
      success: false,
      message: 'Укажите Client-Id и Api-Key Ozon перед синхронизацией.',
    };
  }

  try {
    onProgress?.('Проверка ключа доступа Admin Read Only и складов...', 5);

    // Склады продавца
    let liveWarehouses: OzonWarehouse[] = [];
    try {
      const whRes = await fetchOzonWarehouses({ clientId: cId, apiKey: aKey });
      if (whRes.success) liveWarehouses = whRes.warehouses;
    } catch {
      // safe fallback
    }

    // =========================================================================
    // ШАГ 1: Получаем полный список артикулов продавца с пагинацией
    // =========================================================================
    onProgress?.('Загрузка списка всех товаров из каталога Ozon...', 15);

    const allProductIds: number[] = [];
    const allOfferIds: string[] = [];
    let lastId = '';
    let totalInCatalog = 0;
    const MAX_ITEMS_LIMIT = 500;

    let hasMore = true;
    let pageCount = 0;

    while (hasMore && allProductIds.length < MAX_ITEMS_LIMIT) {
      pageCount++;
      const listRes = await callOzonApi<{
        result?: {
          items?: Array<{ product_id: number; offer_id: string }>;
          total?: number;
          last_id?: string;
        };
      }>(
        '/v3/product/list',
        {
          filter: { visibility: 'ALL' },
          last_id: lastId,
          limit: 100,
        },
        { clientId: cId, apiKey: aKey }
      );

      if (listRes.success && listRes.data?.result?.items) {
        const items = listRes.data.result.items;
        totalInCatalog = listRes.data.result.total || items.length;

        for (const it of items) {
          if (it.product_id && !allProductIds.includes(it.product_id)) {
            allProductIds.push(it.product_id);
            allOfferIds.push(it.offer_id);
          }
        }

        lastId = listRes.data.result.last_id || '';
        if (!lastId || items.length === 0 || allProductIds.length >= totalInCatalog) {
          hasMore = false;
        }
      } else {
        // Фоллбэк на v2 при необходимости
        if (pageCount === 1) {
          const v2Res = await callOzonApi<{
            result?: {
              items?: Array<{ product_id: number; offer_id: string }>;
              total?: number;
            };
          }>(
            '/v2/product/list',
            {
              filter: { visibility: 'ALL' },
              limit: 100,
            },
            { clientId: cId, apiKey: aKey }
          );

          if (v2Res.success && v2Res.data?.result?.items) {
            const items = v2Res.data.result.items;
            totalInCatalog = v2Res.data.result.total || items.length;
            for (const it of items) {
              allProductIds.push(it.product_id);
              allOfferIds.push(it.offer_id);
            }
          }
        }
        hasMore = false;
      }
    }

    if (allProductIds.length === 0) {
      return {
        success: false,
        message: 'В вашем магазине Ozon не найдено активных товаров.',
      };
    }

    onProgress?.(`Найдено ${allProductIds.length} артикулов. Загрузка габаритов, веса и штрихкодов...`, 30);

    // =========================================================================
    // ШАГ 2: Загрузка физических габаритов упаковки и цен из /v2/product/info/list
    // В Ozon API метод /v2/product/info/list является основным:
    // он возвращает в одном запросе реальные габариты (depth, width, height, unit),
    // вес (weight, unit), объемный вес (volume_weight),
    // предельную цену продавца (price, old_price) и цену реализации со скидками (marketing_price)!
    // ВАЖНО: передаем ТОЛЬКО offer_id (никогда оба offer_id и product_id одновременно)
    // =========================================================================
    const attrMap = new Map<string, RawOzonProductAttribute>();
    const CHUNK_SIZE = 50;

    for (let i = 0; i < allOfferIds.length; i += CHUNK_SIZE) {
      const chunkOffers = allOfferIds.slice(i, i + CHUNK_SIZE);
      const chunkIds = allProductIds.slice(i, i + CHUNK_SIZE);

      const percent = Math.min(65, Math.round(30 + (i / allOfferIds.length) * 35));
      onProgress?.(
        `Загрузка реальных габаритов упаковки и каталожных цен (${Math.min(i + CHUNK_SIZE, allOfferIds.length)} / ${allOfferIds.length})...`,
        percent
      );

      // Способ 1 (Основной и точный): /v2/product/info/list по offer_id
      let gotInfo = false;
      const v2InfoRes = await callOzonApi<{
        result?: {
          items?: RawOzonProductAttribute[];
        };
      }>(
        '/v2/product/info/list',
        {
          offer_id: chunkOffers,
        },
        { clientId: cId, apiKey: aKey }
      );

      if (v2InfoRes.success && v2InfoRes.data?.result?.items && v2InfoRes.data.result.items.length > 0) {
        gotInfo = true;
        for (const item of v2InfoRes.data.result.items) {
          if (item.offer_id) attrMap.set(item.offer_id, item);
          if (item.id) attrMap.set(String(item.id), item);
        }
      }

      // Способ 2 (запасной): если по offer_id не вернул, пробуем по product_id
      if (!gotInfo) {
        const v2IdRes = await callOzonApi<{
          result?: {
            items?: RawOzonProductAttribute[];
          };
        }>(
          '/v2/product/info/list',
          {
            product_id: chunkIds,
          },
          { clientId: cId, apiKey: aKey }
        );

        if (v2IdRes.success && v2IdRes.data?.result?.items && v2IdRes.data.result.items.length > 0) {
          gotInfo = true;
          for (const item of v2IdRes.data.result.items) {
            if (item.offer_id) attrMap.set(item.offer_id, item);
            if (item.id) attrMap.set(String(item.id), item);
          }
        }
      }

      // Способ 3 (дополнительное обогащение): /v3/products/info/attributes для догрузки штрихкодов или названий
      try {
        const v3AttrRes = await callOzonApi<{
          result?: Array<{
            id: number;
            offer_id: string;
            name?: string;
            barcode?: string;
            barcodes?: string[];
          }>;
        }>(
          '/v3/products/info/attributes',
          {
            filter: {
              offer_id: chunkOffers,
            },
            limit: CHUNK_SIZE,
          },
          { clientId: cId, apiKey: aKey }
        );

        if (v3AttrRes.success && Array.isArray(v3AttrRes.data?.result)) {
          for (const v3Item of v3AttrRes.data.result) {
            const existing = attrMap.get(v3Item.offer_id) || attrMap.get(String(v3Item.id));
            if (!existing) {
              attrMap.set(v3Item.offer_id, {
                id: v3Item.id,
                offer_id: v3Item.offer_id,
                name: v3Item.name || '',
                barcode: v3Item.barcode || (v3Item.barcodes && v3Item.barcodes[0]) || '',
                barcodes: v3Item.barcodes,
              });
            } else {
              if (!existing.barcode && v3Item.barcode) existing.barcode = v3Item.barcode;
              if ((!existing.barcodes || existing.barcodes.length === 0) && v3Item.barcodes) {
                existing.barcodes = v3Item.barcodes;
              }
              if (!existing.name && v3Item.name) existing.name = v3Item.name;
            }
          }
        }
      } catch {
        // safe fallback if v3 attributes fails
      }
    }

    // =========================================================================
    // ШАГ 3: Загрузка цен реализации и комиссий Ozon (/v5/product/info/prices)
    // ВАЖНО: В filter для /v5/product/info/prices НЕЛЬЗЯ передавать visibility: "ALL" —
    // Ozon API v5 возвращает ошибку 400 Bad Request при наличии visibility!
    // =========================================================================
    onProgress?.('Загрузка цен реализации и официальных ставок комиссий Ozon FBO/FBS...', 70);

    const priceMap = new Map<string, RawOzonProductPrice>();

    for (let i = 0; i < allOfferIds.length; i += CHUNK_SIZE) {
      const chunkOffers = allOfferIds.slice(i, i + CHUNK_SIZE);
      const chunkIds = allProductIds.slice(i, i + CHUNK_SIZE);

      const percent = Math.min(90, Math.round(70 + (i / allOfferIds.length) * 20));
      onProgress?.(
        `Загрузка актуальных цен и тарифов (${Math.min(i + CHUNK_SIZE, allOfferIds.length)} / ${allOfferIds.length})...`,
        percent
      );

      // Запрос цен и комиссий в v5 БЕЗ visibility:
      let pricesLoaded = false;
      const v5Res = await callOzonApi<{
        result?: {
          items?: RawOzonProductPrice[];
        };
      }>(
        '/v5/product/info/prices',
        {
          filter: {
            offer_id: chunkOffers,
          },
          limit: CHUNK_SIZE,
        },
        { clientId: cId, apiKey: aKey }
      );

      if (v5Res.success && v5Res.data?.result?.items && v5Res.data.result.items.length > 0) {
        pricesLoaded = true;
        for (const p of v5Res.data.result.items) {
          if (p.offer_id) priceMap.set(p.offer_id, p);
          if (p.product_id) priceMap.set(String(p.product_id), p);
        }
      }

      if (!pricesLoaded) {
        // Фоллбэк 1: по product_id в v5
        const v5IdRes = await callOzonApi<{
          result?: {
            items?: RawOzonProductPrice[];
          };
        }>(
          '/v5/product/info/prices',
          {
            filter: {
              product_id: chunkIds,
            },
            limit: CHUNK_SIZE,
          },
          { clientId: cId, apiKey: aKey }
        );

        if (v5IdRes.success && v5IdRes.data?.result?.items && v5IdRes.data.result.items.length > 0) {
          pricesLoaded = true;
          for (const p of v5IdRes.data.result.items) {
            if (p.offer_id) priceMap.set(p.offer_id, p);
            if (p.product_id) priceMap.set(String(p.product_id), p);
          }
        }
      }

      if (!pricesLoaded) {
        // Фоллбэк 2: /v4/product/info/prices
        const v4Res = await callOzonApi<{
          result?: {
            items?: RawOzonProductPrice[];
          };
        }>(
          '/v4/product/info/prices',
          {
            filter: {
              offer_id: chunkOffers,
            },
            limit: CHUNK_SIZE,
          },
          { clientId: cId, apiKey: aKey }
        );

        if (v4Res.success && v4Res.data?.result?.items && v4Res.data.result.items.length > 0) {
          pricesLoaded = true;
          for (const p of v4Res.data.result.items) {
            if (p.offer_id) priceMap.set(p.offer_id, p);
            if (p.product_id) priceMap.set(String(p.product_id), p);
          }
        }
      }
    }

    onProgress?.('Формирование расчетной матрицы юнит-экономики...', 95);

    // =========================================================================
    // ШАГ 4: Сборка итогового массива ProductUnitData с реальными данными Ozon
    // =========================================================================
    const existingMap = new Map<string, ProductUnitData>();
    for (const ep of existingProducts) {
      existingMap.set(ep.sku, ep);
      existingMap.set(ep.sku.toLowerCase(), ep);
      if (ep.id) existingMap.set(ep.id, ep);
    }

    let pricesUpdatedCount = 0;
    let dimensionsUpdatedCount = 0;
    let commissionsUpdatedCount = 0;

    const assignedWarehouse = options?.selectedWarehouse || DEFAULT_WAREHOUSE_NAME;
    const assignedWarehouseType: 'FBO' | 'FBS' = options?.selectedWarehouseType || 'FBO';
    const assignedWarehouseId = options?.selectedWarehouseId;

    const fetchedProducts: ProductUnitData[] = [];

    for (let i = 0; i < allOfferIds.length; i++) {
      const offerId = allOfferIds[i];
      const prodId = allProductIds[i];

      const attr = attrMap.get(offerId) || attrMap.get(String(prodId));
      const priceInfo = priceMap.get(offerId) || priceMap.get(String(prodId));
      const prev = existingMap.get(offerId) || existingMap.get(offerId.toLowerCase()) || existingMap.get(String(prodId));

      // 1. Предельная розничная цена реализации (настоящая цена из Ozon)
      // Приоритеты:
      // a) priceInfo.price.price (из /v5/product/info/prices)
      // b) attr.price (из /v2/product/info/list)
      // c) priceInfo.price.retail_price
      // d) ранее сохраненная prev.retailPrice
      let retailPrice = 0;
      let oldRetailPrice: number | undefined;

      const rawPrice = priceInfo?.price?.price ?? attr?.price ?? priceInfo?.price?.retail_price;
      if (rawPrice !== undefined && rawPrice !== null && rawPrice !== '') {
        const parsed = parseFloat(String(rawPrice).replace(',', '.'));
        if (!isNaN(parsed) && parsed > 0) {
          retailPrice = parsed;
          pricesUpdatedCount++;
        }
      }

      if (retailPrice === 0 && prev?.retailPrice) {
        retailPrice = prev.retailPrice;
      }

      // Старая зачеркнутая цена (если есть в Ozon)
      const rawOldPrice = priceInfo?.price?.old_price ?? attr?.old_price;
      if (rawOldPrice !== undefined && rawOldPrice !== null && rawOldPrice !== '') {
        const parsedOld = parseFloat(String(rawOldPrice).replace(',', '.'));
        if (!isNaN(parsedOld) && parsedOld > retailPrice) {
          oldRetailPrice = parsedOld;
        }
      } else if (prev?.oldRetailPrice) {
        oldRetailPrice = prev.oldRetailPrice;
      }

      // 2. Цена реализации (фактическая цена продажи покупателю на Ozon / база налога 11%):
      // Подгружается напрямую из Ozon: marketing_seller_price или marketing_price!
      // Если у товара нет акционной скидки Ozon, цена реализации равна розничной цене (retailPrice).
      let taxPrice = retailPrice;

      const rawMarketingPrice =
        priceInfo?.price?.marketing_seller_price ??
        priceInfo?.price?.marketing_price ??
        attr?.marketing_price;

      if (rawMarketingPrice !== undefined && rawMarketingPrice !== null && rawMarketingPrice !== '') {
        const parsedM = parseFloat(String(rawMarketingPrice).replace(',', '.'));
        if (!isNaN(parsedM) && parsedM > 0) {
          taxPrice = parsedM;
        } else if (prev?.taxPrice !== undefined && prev.taxPrice > 0) {
          taxPrice = prev.taxPrice;
        } else if (options?.defaultTaxPriceRatio && options.defaultTaxPriceRatio < 1.0) {
          taxPrice = Math.round(retailPrice * options.defaultTaxPriceRatio);
        }
      } else if (prev?.taxPrice !== undefined && prev.taxPrice > 0 && prev.retailPrice === retailPrice) {
        taxPrice = prev.taxPrice;
      } else if (options?.defaultTaxPriceRatio && options.defaultTaxPriceRatio < 1.0) {
        taxPrice = Math.round(retailPrice * options.defaultTaxPriceRatio);
      } else {
        taxPrice = retailPrice;
      }

      // 3. Физические габариты упаковки и расчет точного объема в литрах
      const depth = Number(attr?.depth) || 0;
      const width = Number(attr?.width) || 0;
      const height = Number(attr?.height) || 0;
      const weight = Number(attr?.weight) || 0;
      let unit = (attr?.dimension_unit || 'мм').toLowerCase();
      const weightUnit = (attr?.weight_unit || 'г').toLowerCase();

      let volumeLiters = 0;

      if (depth > 0 && width > 0 && height > 0) {
        dimensionsUpdatedCount++;
        if (unit === 'см' || unit === 'cm') {
          // В сантиметрах: (Д * Ш * В) / 1000 = литры
          volumeLiters = Math.round(((depth * width * height) / 1000) * 100) / 100;
        } else {
          // В миллиметрах: (Д * Ш * В) / 1 000 000 = литры
          volumeLiters = Math.round(((depth * width * height) / 1000000) * 100) / 100;
          unit = 'мм';
        }
      } else if (priceInfo?.volume_weight && Number(priceInfo.volume_weight) > 0) {
        // Фоллбэк через объемный вес Ozon:
        // Объемный вес Ozon (кг) = V(литры) / 5  =>  V(литры) = объемный вес * 5
        volumeLiters = Math.round(Number(priceInfo.volume_weight) * 5 * 100) / 100;
      } else if (attr?.volume_weight && Number(attr.volume_weight) > 0) {
        volumeLiters = Math.round(Number(attr.volume_weight) * 5 * 100) / 100;
      } else if (prev?.volumeLiters && prev.volumeLiters > 0) {
        volumeLiters = prev.volumeLiters;
      }

      if (volumeLiters < 0.01) {
        volumeLiters = prev?.volumeLiters || 0.1;
      }

      // 4. Себестоимость / Закупка (COGS):
      // Вводится пользователем самостоятельно и СТРОГО сохраняется при любых синхронизациях!
      let cogs = 0;
      if (prev?.cogs !== undefined && prev.cogs > 0) {
        cogs = prev.cogs;
      } else if (options?.defaultCogsPercent) {
        cogs = Math.round(retailPrice * (options.defaultCogsPercent / 100));
      } else {
        cogs = Math.round(retailPrice * 0.25);
      }

      // 5. Процент рекламы (ДРР %):
      // Вводится пользователем самостоятельно и СТРОГО сохраняется при любых синхронизациях!
      const adSpendPercent = prev?.adSpendPercent !== undefined
        ? prev.adSpendPercent
        : (options?.defaultAdSpendPercent ?? 16);

      const plannedSales = prev?.plannedSalesUnits ?? 200;

      // 6. Сборы Ozon (Комиссия FBO/FBS, последняя миля, эквайринг, логистика)
      const apiFboCommission = priceInfo?.commissions?.sales_percent_fbo ?? priceInfo?.commissions?.sales_percent;
      let commissionOver300 = 52;

      if (apiFboCommission && apiFboCommission > 0) {
        commissionOver300 = apiFboCommission;
        commissionsUpdatedCount++;
      } else if (prev?.commissionOver300) {
        commissionOver300 = prev.commissionOver300;
      }

      const commissionUnder300 = prev?.commissionUnder300 ?? 23;
      const acquiringPercent = priceInfo?.commissions?.acquiring
        ? Number(priceInfo.commissions.acquiring)
        : (prev?.acquiringPercent ?? 1.5);

      const crossDockFixed = assignedWarehouseType === 'FBS' ? 0 : (prev?.crossDockFixed ?? 1.63);
      const fulfillmentFixed = assignedWarehouseType === 'FBS' ? 30 : (prev?.fulfillmentFixed ?? 10);

      // Штрихкод и наименование
      const barcode = attr?.barcode || (attr?.barcodes && attr.barcodes[0]) || '';
      const title = attr?.name || `Товар Ozon ${offerId}`;

      const dimensionsData: ProductDimensions = {
        depth,
        width,
        height,
        weight,
        unit,
        weightUnit,
      };

      fetchedProducts.push({
        id: prev?.id || `ozon_${prodId}_${offerId}`,
        sku: offerId,
        title: title,
        barcode: barcode,
        category: prev?.category || 'Каталог Ozon',
        warehouse: assignedWarehouse,
        warehouseType: assignedWarehouseType,
        warehouseId: assignedWarehouseId,
        dimensions: dimensionsData,
        retailPrice: retailPrice,
        oldRetailPrice: oldRetailPrice,
        taxPrice: taxPrice,
        cogs: cogs,
        volumeLiters: volumeLiters,
        adSpendPercent: adSpendPercent,
        fulfillmentFixed: fulfillmentFixed,
        ddvRub: prev?.ddvRub ?? 7.0,
        lpRub: prev?.lpRub ?? 0.1,
        crossDockFixed: crossDockFixed,
        lastMilePercent: prev?.lastMilePercent ?? 4.9,
        acquiringPercent: acquiringPercent,
        commissionUnder300: commissionUnder300,
        commissionOver300: commissionOver300,
        forceMajeurePercent: 1.0,
        taxPercent: prev?.taxPercent ?? 11,
        plannedSalesUnits: plannedSales,
        notes: `Ozon API: Габариты ${depth}×${width}×${height} ${unit}, вес ${weight}${weightUnit}, объем ${volumeLiters}л. Склад: ${assignedWarehouse}. Комиссия: ${commissionOver300}%. ${barcode ? `Штрихкод: ${barcode}` : ''}`,
      });
    }

    onProgress?.('Синхронизация успешно завершена!', 100);

    saveOzonCredentials({
      clientId: cId,
      apiKey: aKey,
      keyType: 'admin_read_only',
      lastSync: new Date().toISOString(),
      sellerName: `Ozon Seller (${cId})`,
      totalProducts: fetchedProducts.length,
      warehousesCount: liveWarehouses.length,
    });

    return {
      success: true,
      products: fetchedProducts,
      totalSynced: fetchedProducts.length,
      warehouses: liveWarehouses,
      stats: {
        pricesUpdated: pricesUpdatedCount,
        dimensionsUpdated: dimensionsUpdatedCount,
        commissionsUpdated: commissionsUpdatedCount,
      },
      message: `Успешно загружено ${fetchedProducts.length} позиций из Ozon с ключом «Администратор (только чтение)»! Цены реализации, физические габариты упаковок (${dimensionsUpdatedCount} шт), склад (${assignedWarehouse}) и официальные комиссии Ozon обновлены.`,
    };
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : 'Неизвестная ошибка синхронизации';
    return {
      success: false,
      message: `Ошибка при синхронизации с Ozon: ${msg}`,
    };
  }
}

/**
 * Демо-каталог реальных товаров Ozon (для тестирования без персонального API ключа)
 */
export const DEMO_OZON_LIVE_CATALOG: ProductUnitData[] = [
  {
    id: 'ozon_live_demo_1',
    sku: 'OZN-94821034',
    title: 'Крем для лица восстанавливающий с гиалуроновой кислотой 50мл',
    barcode: '4607001234567',
    category: 'Уход за лицом',
    warehouse: 'Склад FBO Тула / Москва (Центр)',
    warehouseType: 'FBO',
    retailPrice: 590,
    taxPrice: 531,
    cogs: 110,
    volumeLiters: 0.18,
    dimensions: { depth: 60, width: 60, height: 50, weight: 120, unit: 'мм', weightUnit: 'г' },
    adSpendPercent: 12,
    fulfillmentFixed: 10,
    ddvRub: 7.0,
    lpRub: 0.1,
    crossDockFixed: 1.63,
    lastMilePercent: 4.9,
    acquiringPercent: 1.5,
    commissionUnder300: 23,
    commissionOver300: 52,
    forceMajeurePercent: 1.0,
    taxPercent: 11,
    plannedSalesUnits: 1400,
    notes: 'Актуальные данные Ozon: габариты 60x60x50 мм, вес 120г. FBO Кластер Центр.',
  },
  {
    id: 'ozon_live_demo_2',
    sku: 'OZN-77492104',
    title: 'Пенка для умывания очищающая с центеллой азиатской 150мл',
    barcode: '4607001234574',
    category: 'Очищение кожи',
    warehouse: 'Склад FBO Тула / Москва (Центр)',
    warehouseType: 'FBO',
    retailPrice: 480,
    taxPrice: 432,
    cogs: 95,
    volumeLiters: 0.32,
    dimensions: { depth: 160, width: 50, height: 40, weight: 180, unit: 'мм', weightUnit: 'г' },
    adSpendPercent: 10,
    fulfillmentFixed: 10,
    ddvRub: 7.0,
    lpRub: 0.1,
    crossDockFixed: 1.63,
    lastMilePercent: 4.9,
    acquiringPercent: 1.5,
    commissionUnder300: 23,
    commissionOver300: 52,
    forceMajeurePercent: 1.0,
    taxPercent: 11,
    plannedSalesUnits: 950,
    notes: 'Габариты 160x50x40 мм, объем 0.32л. Тариф лог: 84 ₽.',
  },
  {
    id: 'ozon_live_demo_3',
    sku: 'OZN-33819402',
    title: 'Бальзам для губ восстанавливающий с пантенолом (эконом-сегмент)',
    barcode: '4607001234581',
    category: 'Уход за губами',
    warehouse: 'Склад FBO Тула / Москва (Центр)',
    warehouseType: 'FBO',
    retailPrice: 199,
    taxPrice: 179,
    cogs: 32,
    volumeLiters: 0.05,
    dimensions: { depth: 50, width: 40, height: 25, weight: 20, unit: 'мм', weightUnit: 'г' },
    adSpendPercent: 8,
    fulfillmentFixed: 10,
    ddvRub: 7.0,
    lpRub: 0.1,
    crossDockFixed: 1.63,
    lastMilePercent: 4.9,
    acquiringPercent: 1.5,
    commissionUnder300: 23,
    commissionOver300: 52,
    forceMajeurePercent: 1.0,
    taxPercent: 11,
    plannedSalesUnits: 3200,
    notes: 'Товар до 300 ₽: спец-тариф комиссии 23% и льготная логистика 20 ₽.',
  },
  {
    id: 'ozon_live_demo_4',
    sku: 'OZN-66291045',
    title: 'Сыворотка для лица с ниацинамидом и цинком 30мл',
    barcode: '4607001234598',
    category: 'Сыворотки',
    warehouse: 'Склад FBO Тула / Москва (Центр)',
    warehouseType: 'FBO',
    retailPrice: 620,
    taxPrice: 558,
    cogs: 115,
    volumeLiters: 0.12,
    dimensions: { depth: 100, width: 40, height: 30, weight: 95, unit: 'мм', weightUnit: 'г' },
    adSpendPercent: 11,
    fulfillmentFixed: 10,
    ddvRub: 7.0,
    lpRub: 0.1,
    crossDockFixed: 1.63,
    lastMilePercent: 4.9,
    acquiringPercent: 1.5,
    commissionUnder300: 23,
    commissionOver300: 52,
    forceMajeurePercent: 1.0,
    taxPercent: 11,
    plannedSalesUnits: 1800,
    notes: 'Синхронизировано из Ozon: габариты 100x40x30 мм, вес 95г.',
  },
  {
    id: 'ozon_live_demo_5',
    sku: 'OZN-11849203',
    title: 'Мицеллярная вода для снятия макияжа 400мл',
    barcode: '4607001234604',
    category: 'Демакияж',
    warehouse: 'Склад FBO Тула / Москва (Центр)',
    warehouseType: 'FBO',
    retailPrice: 390,
    taxPrice: 351,
    cogs: 78,
    volumeLiters: 0.65,
    dimensions: { depth: 190, width: 70, height: 50, weight: 440, unit: 'мм', weightUnit: 'г' },
    adSpendPercent: 9,
    fulfillmentFixed: 10,
    ddvRub: 7.0,
    lpRub: 0.1,
    crossDockFixed: 1.63,
    lastMilePercent: 4.9,
    acquiringPercent: 1.5,
    commissionUnder300: 23,
    commissionOver300: 52,
    forceMajeurePercent: 1.0,
    taxPercent: 11,
    plannedSalesUnits: 800,
    notes: 'Габариты 190x70x50 мм, объем 0.65л. Тариф лог: 88 ₽.',
  },
  {
    id: 'ozon_live_demo_6',
    sku: 'OZN-55029314',
    title: 'Гидрогелевые патчи для глаз с муцином улитки (60 шт)',
    barcode: '4607001234611',
    category: 'Уход за кожей вокруг глаз',
    warehouse: 'Склад FBO Тула / Москва (Центр)',
    warehouseType: 'FBO',
    retailPrice: 750,
    taxPrice: 675,
    cogs: 160,
    volumeLiters: 0.35,
    dimensions: { depth: 85, width: 85, height: 48, weight: 160, unit: 'мм', weightUnit: 'г' },
    adSpendPercent: 14,
    fulfillmentFixed: 10,
    ddvRub: 7.0,
    lpRub: 0.1,
    crossDockFixed: 1.63,
    lastMilePercent: 4.9,
    acquiringPercent: 1.5,
    commissionUnder300: 23,
    commissionOver300: 52,
    forceMajeurePercent: 1.0,
    taxPercent: 11,
    plannedSalesUnits: 1200,
    notes: 'Ozon FBO: высокая маржа, стабильный оборот.',
  },
];

/**
 * Калькулятор официальной логистики Ozon по габаритам (см) и весу (кг)
 */
export function calculateOzonDimensionsLogistics(
  lengthCm: number,
  widthCm: number,
  heightCm: number,
  retailPrice: number
): {
  volumeLiters: number;
  baseTariff: number;
  notes: string;
} {
  const vol = Math.max(0.01, (lengthCm * widthCm * heightCm) / 1000);
  const roundedVol = Math.round(vol * 100) / 100;
  const tariff = getLogisticsTariff(roundedVol, retailPrice);

  let notes = '';
  if (retailPrice <= 300) {
    notes = `Льготный тариф Ozon для товаров до 300 ₽ (${tariff} ₽ при объеме ${roundedVol} л)`;
  } else {
    notes = `Стандартный тариф FBO Ozon свыше 300 ₽ (${tariff} ₽ при объеме ${roundedVol} л)`;
  }

  return {
    volumeLiters: roundedVol,
    baseTariff: tariff,
    notes,
  };
}
