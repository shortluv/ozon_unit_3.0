/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ProductUnitData } from './types/unitEconomics';
import { INITIAL_PRODUCTS, MARKETPLACE_PRESETS } from './utils/calculator';
import { exportProductsToExcel } from './utils/excelHelper';
import { Header } from './components/Header';
import { MetricsOverview } from './components/MetricsOverview';
import { ProductTable } from './components/ProductTable';
import { SingleCalculator } from './components/SingleCalculator';
import { SensitivityMatrix } from './components/SensitivityMatrix';
import { EconomicsAdvisor } from './components/EconomicsAdvisor';
import { ImportModal } from './components/ImportModal';
import { NewProductModal } from './components/NewProductModal';
import { OzonSyncModal } from './components/OzonSyncModal';
import { getSavedOzonCredentials, OzonCategoryTariff } from './services/ozonApi';
import { RotateCcw, Sparkles, Shield, ArrowRight, RefreshCw } from 'lucide-react';

const STORAGE_KEY = 'unit_economy_ozon_oct_v3';

export default function App() {
  const [products, setProducts] = useState<ProductUnitData[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to load products from localStorage', e);
    }
    return INITIAL_PRODUCTS;
  });

  const [activeTab, setActiveTab] = useState<'catalog' | 'single' | 'matrix' | 'advisor'>('catalog');
  const [selectedProduct, setSelectedProduct] = useState<ProductUnitData | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>('all');
  
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isNewProductOpen, setIsNewProductOpen] = useState(false);
  const [isOzonSyncOpen, setIsOzonSyncOpen] = useState(false);
  const [isOzonConnected, setIsOzonConnected] = useState(false);

  // Check saved credentials on load
  useEffect(() => {
    const creds = getSavedOzonCredentials();
    setIsOzonConnected(!!(creds?.clientId && creds?.apiKey));
  }, [isOzonSyncOpen]);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
    } catch (e) {
      console.error('Failed to persist products', e);
    }
  }, [products]);

  // Update single product
  const handleUpdateProduct = (updated: ProductUnitData) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    if (selectedProduct && selectedProduct.id === updated.id) {
      setSelectedProduct(updated);
    }
  };

  // Delete product
  const handleDeleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    if (selectedProduct && selectedProduct.id === id) {
      setSelectedProduct(null);
    }
  };

  // Duplicate product
  const handleDuplicateProduct = (prod: ProductUnitData) => {
    const clone: ProductUnitData = {
      ...prod,
      id: `prod_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      sku: `${prod.sku}-COPY`,
      title: `${prod.title} (Копия)`,
    };
    setProducts((prev) => [clone, ...prev]);
  };

  // Add new product
  const handleAddProduct = (newProd: ProductUnitData) => {
    setProducts((prev) => [newProd, ...prev]);
    setSelectedProduct(newProd);
  };

  // Reset to original Ozon store data
  const handleResetToOriginal = () => {
    if (window.confirm('Сбросить список к исходным 11 товарам из вашей таблицы Excel?')) {
      setProducts(INITIAL_PRODUCTS);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_PRODUCTS));
    }
  };

  // Apply marketplace preset to all items
  const handleApplyPresetToAll = (presetId: string) => {
    const preset = MARKETPLACE_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;

    setProducts((prev) =>
      prev.map((p) => ({
        ...p,
        commissionUnder300: preset.commissionUnder300,
        commissionOver300: preset.commissionOver300,
        lastMilePercent: preset.lastMilePercent,
        acquiringPercent: preset.acquiringPercent,
        crossDockFixed: preset.crossDockFixed,
        fulfillmentFixed: preset.fulfillmentFixed,
        forceMajeurePercent: preset.forceMajeurePercent,
        taxPercent: preset.taxPercent,
      }))
    );
  };

  // Apply official Ozon category tariff to all items
  const handleApplyOzonTariffToAll = (tariff: OzonCategoryTariff) => {
    setProducts((prev) =>
      prev.map((p) => ({
        ...p,
        commissionUnder300: tariff.commissionUnder300,
        commissionOver300: tariff.commissionOver300,
        lastMilePercent: tariff.lastMilePercent,
        acquiringPercent: tariff.acquiringPercent,
        crossDockFixed: tariff.crossDockFixed,
        fulfillmentFixed: tariff.fulfillmentFixed,
      }))
    );
  };

  // Update warehouse for all products
  const handleUpdateWarehouseAll = (warehouseName: string, warehouseType: 'FBO' | 'FBS') => {
    setProducts((prev) =>
      prev.map((p) => ({
        ...p,
        warehouse: warehouseName,
        warehouseType: warehouseType,
        crossDockFixed: warehouseType === 'FBS' ? 0 : 1.63,
        fulfillmentFixed: warehouseType === 'FBS' ? 30 : 10,
      }))
    );
  };

  // Deep dive selection
  const handleSelectForDeepDive = (product: ProductUnitData) => {
    setSelectedProduct(product);
    setActiveTab('single');
  };

  // Filter losses and jump to catalog
  const handleFilterLosses = () => {
    setActiveFilter((prev) => (prev === 'loss' ? 'all' : 'loss'));
    setActiveTab('catalog');
  };

  // Export to Excel
  const handleExport = () => {
    exportProductsToExcel(products);
  };

  // Import handler
  const handleImportProducts = (newItems: ProductUnitData[], mode: 'replace' | 'append') => {
    if (mode === 'replace') {
      setProducts(newItems);
    } else {
      setProducts((prev) => [...newItems, ...prev]);
    }
    setActiveTab('catalog');
  };

  return (
    <div className="min-h-screen bg-[#080b11] text-slate-100 flex flex-col font-sans selection:bg-emerald-500/25 selection:text-emerald-200">
      {/* 3-Zone Top Navigation Bar (Uptic Style) */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenImport={() => setIsImportOpen(true)}
        onExport={handleExport}
        onNewProduct={() => setIsNewProductOpen(true)}
        onOpenOzonSync={() => setIsOzonSyncOpen(true)}
        isOzonConnected={isOzonConnected}
        productCount={products.length}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
        
        {/* Expressive Hero Banner (Uptic-style) */}
        <section className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-[#111827]/80 to-[#0e1420]/50 border border-white/[0.08] p-6 lg:p-8 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.06)]">
          <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="space-y-2 max-w-2xl">
              <div className="flex items-center gap-2 text-xs font-medium text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                <span>Финансовый движок на базе тарифов Ozon</span>
                <span className="text-slate-600" aria-hidden="true">·</span>
                <span className="text-slate-400">Склад Тула / Москва</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white leading-tight font-sans">
                Автоматизированная юнит-экономика товарной матрицы
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                Меняйте только <strong className="text-slate-200">4 параметра</strong>: предельную цену, закупку, литраж и процент рекламы. Логистика, комиссионная ступень 300 ₽ и налоги пересчитываются мгновенно по формулам вашей таблицы Excel.
              </p>
            </div>

            <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 shrink-0">
              <button
                onClick={() => setIsOzonSyncOpen(true)}
                className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-blue-300 bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/30 hover:border-blue-500/50 rounded-xl transition-all cursor-pointer shadow-[0_0_15px_rgba(59,130,246,0.15)]"
                title="Подключить личный кабинет Ozon или обновить тарифы"
              >
                <RefreshCw className="w-3.5 h-3.5 text-blue-400" />
                <span>Ozon API & Тарифы</span>
              </button>

              <button
                onClick={handleResetToOriginal}
                className="flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-300 bg-[#141b2b] hover:bg-[#1a2338] border border-white/[0.08] hover:border-white/[0.15] rounded-xl transition-all cursor-pointer shadow-sm"
                title="Восстановить исходные 11 позиций из файла Excel"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
                <span>Сбросить к исходным (11 товаров)</span>
              </button>

              <button
                onClick={() => setActiveTab('single')}
                className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl transition-all shadow-[0_0_20px_rgba(16,185,129,0.2)] hover:shadow-[0_0_25px_rgba(16,185,129,0.35)] cursor-pointer"
              >
                <span>Экспресс-моделирование</span>
                <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />
              </button>
            </div>
          </div>

          {/* Ambient background glow */}
          <div className="absolute -top-24 -right-24 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
        </section>

        {/* Live KPI Metrics Strip */}
        <MetricsOverview
          products={products}
          onFilterLosses={handleFilterLosses}
          activeFilter={activeFilter}
        />

        {/* Mobile Navigation Tabs */}
        <div className="flex md:hidden items-center gap-1 p-1 bg-[#0e1420] border border-white/[0.08] rounded-xl overflow-x-auto shadow-sm">
          <button
            onClick={() => setActiveTab('catalog')}
            className={`flex-1 py-1.5 px-3 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
              activeTab === 'catalog' ? 'bg-white/[0.1] text-white' : 'text-slate-400'
            }`}
          >
            Таблица ({products.length})
          </button>
          <button
            onClick={() => setActiveTab('single')}
            className={`flex-1 py-1.5 px-3 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
              activeTab === 'single' ? 'bg-white/[0.1] text-white' : 'text-slate-400'
            }`}
          >
            Калькулятор
          </button>
          <button
            onClick={() => setActiveTab('matrix')}
            className={`flex-1 py-1.5 px-3 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
              activeTab === 'matrix' ? 'bg-white/[0.1] text-white' : 'text-slate-400'
            }`}
          >
            Матрица
          </button>
          <button
            onClick={() => setActiveTab('advisor')}
            className={`flex-1 py-1.5 px-3 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
              activeTab === 'advisor' ? 'bg-white/[0.1] text-white' : 'text-slate-400'
            }`}
          >
            Советы
          </button>
        </div>

        {/* View Routing */}
        {activeTab === 'catalog' && (
          <div className="space-y-6">
            <ProductTable
              products={products}
              onUpdateProduct={handleUpdateProduct}
              onDeleteProduct={handleDeleteProduct}
              onDuplicateProduct={handleDuplicateProduct}
              onSelectForDeepDive={handleSelectForDeepDive}
              onApplyPresetToAll={handleApplyPresetToAll}
              onUpdateWarehouseAll={handleUpdateWarehouseAll}
              activeFilter={activeFilter}
              setActiveFilter={setActiveFilter}
            />
          </div>
        )}

        {activeTab === 'single' && (
          <SingleCalculator
            products={products}
            selectedProduct={selectedProduct}
            onSaveProduct={handleUpdateProduct}
            onSaveAsNew={handleAddProduct}
          />
        )}

        {activeTab === 'matrix' && (
          <SensitivityMatrix
            products={products}
            selectedProduct={selectedProduct}
          />
        )}

        {activeTab === 'advisor' && (
          <EconomicsAdvisor
            products={products}
            onSelectProduct={handleSelectForDeepDive}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/[0.06] bg-[#06080d] py-6 mt-12 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">ЮнитЭкономика</span>
            <span aria-hidden="true">·</span>
            <span>Расчет по тарифной сетке Ozon FBO (Тула/Москва)</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Порог 300 ₽: 23% / 52% комиссия</span>
            <span aria-hidden="true">·</span>
            <span>Автоматический пересчет формул Excel</span>
          </div>
        </div>
      </footer>

      {/* Excel Import Modal */}
      <ImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onImportProducts={handleImportProducts}
      />

      {/* Add New Product Modal */}
      <NewProductModal
        isOpen={isNewProductOpen}
        onClose={() => setIsNewProductOpen(false)}
        onAddProduct={handleAddProduct}
      />

      {/* Ozon Live Sync & Tariffs Modal */}
      <OzonSyncModal
        isOpen={isOzonSyncOpen}
        onClose={() => setIsOzonSyncOpen(false)}
        currentProducts={products}
        onImportProducts={handleImportProducts}
        onApplyTariffToAll={handleApplyOzonTariffToAll}
      />
    </div>
  );
}
